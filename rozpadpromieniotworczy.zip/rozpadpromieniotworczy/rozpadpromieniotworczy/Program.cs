﻿using System;
using System.Collections.Generic;
using System.IO;

public class Element
{
    public string Nazwa { get; set; }
    public int LiczbaAtomowa { get; set; }
    public double PolowicznyRozpad { get; set; }
}

public class RozpadPromieniotworczy
{
    private const double E = 2.71828;
    private Dictionary<string, Element> elementy = new Dictionary<string, Element>();

    public RozpadPromieniotworczy()
    {
        LoadElements("C:\\Users\\user\\Downloads\\zad2.txt");
    }

    private void LoadElements(string filePath)
    {
        foreach (var line in File.ReadAllLines(filePath))
        {
            var parts = line.Split(' ');
            elementy[parts[0]] = new Element
            {
                Nazwa = parts[0],
                LiczbaAtomowa = int.Parse(parts[1]),
                PolowicznyRozpad = double.Parse(parts[2])
            };
        }
    }

    public void CalculateDecay(string elementName, double masa, double czas)
    {
        if (!elementy.TryGetValue(elementName, out var element))
        {
            Console.WriteLine("Nie znaleziono elementu.");
            return;
        }

        double lambda = Math.Log(2) / element.PolowicznyRozpad;
        double masamolowa = element.LiczbaAtomowa;
        double liczbaatomow = masa / masamolowa;
        double pozostaleatomy = liczbaatomow * Math.Pow(E, -lambda * czas);

        Console.WriteLine($"Element: {element.Nazwa}");
        Console.WriteLine($"Liczba Atomowa: {element.LiczbaAtomowa}");
        Console.WriteLine($"Początkowa liczba atomów: {liczbaatomow}");
        Console.WriteLine($"Pozostała liczba atomów po {czas} jednostkach: {pozostaleatomy}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        RozpadPromieniotworczy kalkulator = new RozpadPromieniotworczy();

        Console.WriteLine("Wpisz nazwę elementu:");
        string elementName = Console.ReadLine();

        Console.WriteLine("Wpisz masę w gramach:");
        double masa = double.Parse(Console.ReadLine());

        Console.WriteLine("Wpisz czas:");
        double czas = double.Parse(Console.ReadLine());

        kalkulator.CalculateDecay(elementName, masa, czas);
    }
}
